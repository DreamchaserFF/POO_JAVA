public class App {
    public static void main(String[] args) {
        Garrafa g1 = new Garrafa("Vidro", "Refri", "Coca-cola", 2);
        // g1.setConteudo("Refrigerante");
        // g1.setMaterial("Vidro");
        // g1.setLitros(2.0f);
        // g1.setRotulo("Coca-Cola");
    
        g1.status();
    }
}

