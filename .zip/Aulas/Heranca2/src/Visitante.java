public class Visitante extends Pessoa{
}
    


