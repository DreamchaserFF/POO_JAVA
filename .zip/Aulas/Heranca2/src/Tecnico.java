public class Tecnico {
    private String reProfissional;

    public String getReProfissional(){
        return reProfissional;
    }

    public void setReProfissional(String reProfissional){
        this.reProfissional = reProfissional;
    }
}
