public interface Interface {
    public abstract void apresentar(); 

    public abstract void status();

    public abstract void ganharLuta();

    public abstract void perderLuta();

    public abstract void empatarLuta();
}
