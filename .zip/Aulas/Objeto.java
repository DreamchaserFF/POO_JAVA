// Toda classe tem três caracteristicas:
// O que ela tem - Atributo
// O que ela faz - Método
// Como ela está - Estado

// Classe Caneta{
//     modelo: String;
//     cor: String;
//     ponta: float;
//     carga: int;
//     tampada: true;

//     Metodo rabiscar(){
//         if(tampada){
//             print("Erro")
//         }
//         else{
//             print("Rabisco")
//         }
//     }
//     Metodo tampar(){
//         tampada = true;
//     }
// }

// Instanciar: Gerar um objeto a partir de uma classe.
// caneta1 = nova Caneta;
// caneta1.cor = "Azul";
// caneta1.ponta = 0.5;
// caneta1.tampada = false;
// caneta1.rabiscar()

// caneta2.cor = nova Caneta;
// caneta2.ponta = "Vermelho";
// caneta2.tampada = true;
// caneta2.rabiscar()
