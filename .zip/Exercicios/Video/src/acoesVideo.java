public interface acoesVideo {
    public abstract void play();
    public abstract void pause();
    public abstract void like();
}
